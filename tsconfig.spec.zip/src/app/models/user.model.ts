export class UserModel {
  id: number = 0;
  name: string = '';
  email: string = '';
  username: string = '';
  password: string = '';
  mobile: number = 0;
}
