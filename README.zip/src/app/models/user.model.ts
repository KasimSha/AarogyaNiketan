export class UserModel {
  id: number = 0;
  name: string = '';
  email: string = '';
  userName: string = '';
  password: string = '';
  mobile: number = 0;
}
